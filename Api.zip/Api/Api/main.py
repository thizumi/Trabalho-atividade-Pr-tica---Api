from fastapi import FastAPI

app = FastAPI(
    title="Bem vindo à Arquitetura e Desenvolvimento de APIs",
    description="API da Padaria - R.U: 4623150, Thiago Marques Izumi",
    version="1.0.0"
)

# Lista inicial de produtos da padaria
produtos = [
    {"id": 1, "nome": "Pão Francês", "preco": 0.80},
    {"id": 2, "nome": "Pão de Queijo", "preco": 2.50},
    {"id": 3, "nome": "Bolo de Cenoura", "preco": 25.00},
    {"id": 4, "nome": "Coxinha", "preco": 6.00},
]


# 🧺 Rota GET para listar produtos
@app.get("/produtos")
def listar_produtos():
    return {
        "padaria": "Bem vindo à Arquitetura e Desenvolvimento de APIs",
        "R.U": "4623150 - Thiago Marques Izumi",
        "produtos": produtos
    }


# ➕ Rota GET para cadastrar novos produtos (do jeito que você pediu)
@app.get("/cadastrar")
def cadastrar_produto(nome: str, preco: float):
    novo_id = len(produtos) + 1
    novo_produto = {"id": novo_id, "nome": nome, "preco": preco}
    produtos.append(novo_produto)

    return {
        "mensagem": "Produto cadastrado com sucesso!",
        "R.U": "4623150 - Thiago Marques Izumi",
        "produto": novo_produto
    }
